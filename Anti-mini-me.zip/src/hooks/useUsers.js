import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../config/firebase';
import { ROLES } from '../utils/constants';

export const useUsers = () => {
    const findTeacherByEmail = async (email) => {
        try {
            const usersRef = collection(db, 'users');
            const q = query(usersRef, where('email', '==', email), where('role', '==', ROLES.TEACHER));
            const querySnapshot = await getDocs(q);

            if (!querySnapshot.empty) {
                const doc = querySnapshot.docs[0];
                return { id: doc.id, ...doc.data() };
            }
            return null;
        } catch (error) {
            console.error('Error finding teacher:', error);
            return null;
        }
    };

    return { findTeacherByEmail };
};
