import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Bell } from 'lucide-react';
import EmptyState from '../components/ui/EmptyState';

export default function Notifications() {
    const { announcements } = useData();
    const [filter, setFilter] = useState('all'); // 'all', 'unread' (mock)

    // Mock read/unread state for demo
    const [readIds, setReadIds] = useState(new Set());

    const handleMarkRead = (id) => {
        const newReadIds = new Set(readIds);
        newReadIds.add(id);
        setReadIds(newReadIds);
    };

    const filteredAnnouncements = announcements.filter(a => {
        if (filter === 'unread') {
            return !readIds.has(a.id);
        }
        return true;
    });

    return (
        <div className="p-6 max-w-4xl mx-auto animate-scaleIn">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Notifications</h1>
                <div className="flex bg-gray-100 dark:bg-gray-800 p-1 rounded-xl">
                    <button
                        onClick={() => setFilter('all')}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === 'all'
                            ? 'bg-white dark:bg-gray-700 text-indigo-600 dark:text-indigo-400 shadow-sm'
                            : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
                            }`}
                    >
                        All
                    </button>
                    <button
                        onClick={() => setFilter('unread')}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === 'unread'
                            ? 'bg-white dark:bg-gray-700 text-indigo-600 dark:text-indigo-400 shadow-sm'
                            : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
                            }`}
                    >
                        Unread
                    </button>
                </div>
            </div>

            <div className="space-y-4">
                {filteredAnnouncements.length === 0 ? (
                    <EmptyState
                        icon={Bell}
                        title="No Notifications"
                        description={filter === 'unread' ? "You have no unread notifications." : "You're all caught up!"}
                        className="py-12"
                    />
                ) : (
                    filteredAnnouncements.map(announcement => (
                        <div
                            key={announcement.id}
                            className={`p-5 rounded-xl border transition-all duration-300 ${readIds.has(announcement.id)
                                ? 'bg-white/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700'
                                : 'bg-indigo-50/80 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-800/50 shadow-sm transform scale-[1.01]'
                                }`}
                        >
                            <div className="flex justify-between items-start mb-2">
                                <h3 className={`font-semibold ${readIds.has(announcement.id) ? 'text-gray-800 dark:text-gray-200' : 'text-indigo-900 dark:text-indigo-100'}`}>
                                    {announcement.title}
                                </h3>
                                <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap ml-4">
                                    {announcement.date}
                                </span>
                            </div>
                            <p className={`text-sm mb-3 ${readIds.has(announcement.id) ? 'text-gray-600 dark:text-gray-400' : 'text-indigo-800 dark:text-indigo-200'}`}>
                                {announcement.content}
                            </p>
                            <div className="flex justify-between items-center">
                                <span className="text-xs font-medium px-2.5 py-1 bg-white/60 dark:bg-gray-700/60 text-gray-600 dark:text-gray-300 rounded-full border border-gray-100 dark:border-gray-600">
                                    {announcement.author}
                                </span>
                                {!readIds.has(announcement.id) && (
                                    <button
                                        onClick={() => handleMarkRead(announcement.id)}
                                        className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 transition-colors"
                                    >
                                        Mark as read
                                    </button>
                                )}
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}
