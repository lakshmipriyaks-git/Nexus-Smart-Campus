import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Users } from 'lucide-react';

import EmptyState from '../ui/EmptyState';

export default function StudentRoster() {
    const { user } = useAuth();
    const { joinRequests, classes, attendance, respondToJoinRequest } = useData();
    const [studentsWithStats, setStudentsWithStats] = useState([]);
    const [pendingRequests, setPendingRequests] = useState([]);

    useEffect(() => {
        // Get all classes taught by this teacher
        const myClasses = classes.filter(c => c.teacherId === user?.id);
        const myClassIds = myClasses.map(c => c.id);

        // Get approved students from those classes
        const approvedStudents = joinRequests.filter(
            req => myClassIds.includes(req.classId) && req.status === 'approved'
        );

        // Get pending requests
        const pending = joinRequests.filter(
            req => myClassIds.includes(req.classId) && req.status === 'pending'
        );
        setPendingRequests(pending);

        // Calculate attendance for each student
        const studentsData = approvedStudents.map(req => {
            // Get all attendance records for this student
            const studentAttendance = attendance.filter(record =>
                record.records && record.records[req.studentId]
            );

            const totalClasses = studentAttendance.length;
            const presentCount = studentAttendance.filter(
                record => record.records[req.studentId] === 'present'
            ).length;
            const lateCount = studentAttendance.filter(
                record => record.records[req.studentId] === 'late'
            ).length;

            const attendancePercent = totalClasses > 0
                ? Math.round(((presentCount + (lateCount * 0.5)) / totalClasses) * 100)
                : 100;

            // Determine risk level based on attendance
            let risk = 'low';
            if (attendancePercent < 60) risk = 'high';
            else if (attendancePercent < 80) risk = 'medium';

            return {
                id: req.studentId,
                name: req.studentName,
                className: myClasses.find(c => c.id === req.classId)?.name || 'Unknown',
                attendance: attendancePercent,
                totalClasses,
                risk
            };
        });

        // Remove duplicates (student might be in multiple classes)
        const uniqueStudents = studentsData.reduce((acc, student) => {
            const existing = acc.find(s => s.id === student.id);
            if (!existing) {
                acc.push(student);
            }
            return acc;
        }, []);



        setStudentsWithStats(uniqueStudents);
    }, [joinRequests, classes, attendance, user]);

    const getRiskBadgeVariant = (risk) => {
        switch (risk) {
            case 'low': return 'success';
            case 'medium': return 'warning';
            case 'high': return 'danger';
            default: return 'default';
        }
    };

    const handleApprove = async (requestId) => {
        await respondToJoinRequest(requestId, 'approved');
    };

    const handleReject = async (requestId) => {
        await respondToJoinRequest(requestId, 'rejected');
    };

    if (studentsWithStats.length === 0 && pendingRequests.length === 0) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Users className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                        Student Roster
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <EmptyState
                        icon={Users}
                        title="No Students Yet"
                        description="Students who join your classes will appear here."
                        className="py-8 border-none bg-transparent"
                    />
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            {/* Pending Requests Section */}
            {pendingRequests.length > 0 && (
                <Card className="border-yellow-200 dark:border-yellow-800 bg-yellow-50/50 dark:bg-yellow-900/10">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-yellow-800 dark:text-yellow-200">
                            <Users className="h-5 w-5" />
                            Pending Join Requests ({pendingRequests.length})
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {pendingRequests.map(req => (
                                <div key={req.id} className="flex items-center justify-between p-4 bg-white/60 dark:bg-gray-800/60 rounded-xl border border-yellow-100 dark:border-yellow-800 shadow-sm backdrop-blur-sm">
                                    <div>
                                        <p className="font-medium text-gray-900 dark:text-gray-100">{req.studentName}</p>
                                        <p className="text-sm text-gray-500 dark:text-gray-400">
                                            wants to join <span className="font-medium text-indigo-600 dark:text-indigo-400">{classes.find(c => c.id === req.classId)?.name}</span>
                                        </p>
                                    </div>
                                    <div className="flex gap-2">
                                        <button
                                            onClick={() => handleApprove(req.id)}
                                            className="px-4 py-1.5 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-all shadow-sm hover:shadow-md"
                                        >
                                            Approve
                                        </button>
                                        <button
                                            onClick={() => handleReject(req.id)}
                                            className="px-4 py-1.5 bg-red-100 text-red-700 text-sm font-medium rounded-lg hover:bg-red-200 transition-all"
                                        >
                                            Reject
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Users className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                        Student Roster ({studentsWithStats.length})
                    </CardTitle>
                </CardHeader>
                <CardContent className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 dark:text-gray-300 uppercase bg-gray-50 dark:bg-gray-800">
                            <tr>
                                <th className="px-4 py-3">Name</th>
                                <th className="px-4 py-3">Class</th>
                                <th className="px-4 py-3">Total Classes</th>
                                <th className="px-4 py-3">Attendance</th>
                                <th className="px-4 py-3">Risk Level</th>
                            </tr>
                        </thead>
                        <tbody>
                            {studentsWithStats.map(student => (
                                <tr key={student.id} className="border-b border-gray-100 dark:border-gray-700 last:border-0 hover:bg-gray-50 dark:hover:bg-gray-700">
                                    <td className="px-4 py-3 font-medium text-gray-900 dark:text-gray-100">{student.name}</td>
                                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{student.className}</td>
                                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{student.totalClasses}</td>
                                    <td className="px-4 py-3">
                                        <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-1.5 max-w-[100px]">
                                            <div
                                                className={`h-1.5 rounded-full ${student.attendance >= 90 ? 'bg-green-500' : student.attendance >= 75 ? 'bg-yellow-500' : 'bg-red-500'}`}
                                                style={{ width: `${student.attendance}%` }}
                                            ></div>
                                        </div>
                                        <span className="text-xs text-gray-500 dark:text-gray-400 mt-1 block">{student.attendance}%</span>
                                    </td>
                                    <td className="px-4 py-3">
                                        <Badge variant={getRiskBadgeVariant(student.risk)}>
                                            {student.risk.toUpperCase()}
                                        </Badge>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </CardContent>
            </Card>
        </div>
    );
}
