import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { AlertTriangle, TrendingDown, UserX, AlertCircle, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AtRiskAnalysis() {
    const { user } = useAuth();
    const { joinRequests, attendance, grades, classes, assessments } = useData();
    const { darkMode } = useTheme();
    const [selectedRiskLevel, setSelectedRiskLevel] = useState('all'); // 'all', 'high', 'medium', 'low'

    // Derive students from joinRequests
    const students = useMemo(() => {
        if (!user?.id) return [];

        // Get classes taught by this teacher
        const myClasses = classes.filter(c => c.teacherId === user.id);
        const myClassIds = myClasses.map(c => c.id);

        // Get approved students
        const approvedRequests = joinRequests.filter(
            req => myClassIds.includes(req.classId) && req.status === 'approved'
        );

        // Map to student objects and deduplicate
        const uniqueStudents = [];
        const seenIds = new Set();

        approvedRequests.forEach(req => {
            if (!seenIds.has(req.studentId)) {
                seenIds.add(req.studentId);
                uniqueStudents.push({
                    id: req.studentId,
                    name: req.studentName,
                    classId: req.classId // Note: Student might be in multiple classes, this picks the first one found. 
                    // For risk analysis, we might want to aggregate across all their classes, 
                    // but for now this matches the previous logic structure.
                });
            }
        });

        return uniqueStudents;
    }, [joinRequests, classes, user]);

    // Calculate Risk Scores
    const riskData = useMemo(() => {
        return students.map(student => {
            // 1. Calculate Attendance %
            const studentAttendance = attendance.filter(a => a.studentId === student.id);
            const totalClasses = studentAttendance.length;
            const presentCount = studentAttendance.filter(a => a.status === 'present').length;
            const attendancePercentage = totalClasses > 0 ? (presentCount / totalClasses) * 100 : 100;

            // 2. Calculate Average Grade %
            const studentGrades = grades.filter(g => g.studentId === student.id);
            const totalGrades = studentGrades.reduce((sum, g) => sum + parseFloat(g.score), 0);
            const maxPossibleScore = studentGrades.reduce((sum, g) => {
                const assessment = assessments.find(a => a.id === g.assessmentId);
                return sum + (assessment ? parseFloat(assessment.maxScore) : 100);
            }, 0);

            // Normalize to 100 scale
            const gradePercentage = maxPossibleScore > 0 ? (totalGrades / maxPossibleScore) * 100 : 100;

            // 3. Risk Algorithm
            // Weights: Attendance (40%), Grades (60%)
            // Risk Score is inverse of performance (lower performance = higher risk)
            const attendanceRisk = (100 - attendancePercentage) * 0.4;
            const gradeRisk = (100 - gradePercentage) * 0.6;
            const riskScore = Math.round(attendanceRisk + gradeRisk);

            let riskLevel = 'low';
            if (riskScore > 40) riskLevel = 'high';
            else if (riskScore > 20) riskLevel = 'medium';

            // Identify specific issues
            const issues = [];
            if (attendancePercentage < 75) issues.push(`Low Attendance (${Math.round(attendancePercentage)}%)`);
            if (gradePercentage < 60) issues.push(`Failing Grades (Avg ${Math.round(gradePercentage)}%)`);
            if (studentGrades.length === 0 && totalClasses > 5) issues.push('No Grades Recorded');

            return {
                ...student,
                attendancePercentage,
                gradePercentage,
                riskScore,
                riskLevel,
                issues,
                className: classes.find(c => c.id === student.classId)?.name || 'Unknown Class'
            };
        }).sort((a, b) => b.riskScore - a.riskScore); // Sort by highest risk first
    }, [students, attendance, grades, classes, assessments]);

    const filteredStudents = selectedRiskLevel === 'all'
        ? riskData
        : riskData.filter(s => s.riskLevel === selectedRiskLevel);

    const stats = {
        high: riskData.filter(s => s.riskLevel === 'high').length,
        medium: riskData.filter(s => s.riskLevel === 'medium').length,
        low: riskData.filter(s => s.riskLevel === 'low').length,
        total: riskData.length
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="border-l-4 border-l-red-500">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">High Risk Students</p>
                            <h3 className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.high}</h3>
                            <p className="text-xs text-red-500 mt-1">Immediate intervention needed</p>
                        </div>
                        <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-full">
                            <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-l-4 border-l-yellow-500">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Medium Risk Students</p>
                            <h3 className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">{stats.medium}</h3>
                            <p className="text-xs text-yellow-500 mt-1">Monitor closely</p>
                        </div>
                        <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-full">
                            <TrendingDown className="h-6 w-6 text-yellow-600 dark:text-yellow-400" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-l-4 border-l-green-500">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Low Risk Students</p>
                            <h3 className="text-2xl font-bold text-green-600 dark:text-green-400">{stats.low}</h3>
                            <p className="text-xs text-green-500 mt-1">On track</p>
                        </div>
                        <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-full">
                            <CheckCircle className="h-6 w-6 text-green-600 dark:text-green-400" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                        <UserX className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                        At-Risk Student Analysis
                    </CardTitle>
                    <div className="flex gap-2">
                        {['all', 'high', 'medium', 'low'].map(level => (
                            <button
                                key={level}
                                onClick={() => setSelectedRiskLevel(level)}
                                className={`px-3 py-1 text-xs font-medium rounded-lg capitalize transition-all ${selectedRiskLevel === level
                                    ? 'bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-700 shadow-sm'
                                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                                    }`}
                            >
                                {level}
                            </button>
                        ))}
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50/50 dark:bg-gray-800/50 backdrop-blur-sm">
                                <tr>
                                    <th className="px-6 py-4 text-left font-semibold text-gray-700 dark:text-gray-300">Student</th>
                                    <th className="px-6 py-4 text-left font-semibold text-gray-700 dark:text-gray-300">Class</th>
                                    <th className="px-6 py-4 text-left font-semibold text-gray-700 dark:text-gray-300">Risk Score</th>
                                    <th className="px-6 py-4 text-left font-semibold text-gray-700 dark:text-gray-300">Key Issues</th>
                                    <th className="px-6 py-4 text-right font-semibold text-gray-700 dark:text-gray-300">Action</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200 dark:divide-gray-700 bg-white/40 dark:bg-gray-800/40 backdrop-blur-sm">
                                {filteredStudents.length === 0 ? (
                                    <tr>
                                        <td colSpan="5" className="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
                                            No students found in this category.
                                        </td>
                                    </tr>
                                ) : (
                                    filteredStudents.map(student => (
                                        <motion.tr
                                            key={student.id}
                                            initial={{ opacity: 0 }}
                                            animate={{ opacity: 1 }}
                                            className="hover:bg-white/60 dark:hover:bg-gray-700/60 transition-colors"
                                        >
                                            <td className="px-6 py-4 font-medium text-gray-900 dark:text-gray-100">
                                                {student.name}
                                            </td>
                                            <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                                                {student.className}
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-16 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                                        <div
                                                            className={`h-full rounded-full ${student.riskLevel === 'high' ? 'bg-red-500' :
                                                                student.riskLevel === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                                                                }`}
                                                            style={{ width: `${student.riskScore}%` }}
                                                        />
                                                    </div>
                                                    <span className={`font-bold ${student.riskLevel === 'high' ? 'text-red-600 dark:text-red-400' :
                                                        student.riskLevel === 'medium' ? 'text-yellow-600 dark:text-yellow-400' : 'text-green-600 dark:text-green-400'
                                                        }`}>
                                                        {student.riskScore}
                                                    </span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="flex flex-wrap gap-1">
                                                    {student.issues.length > 0 ? (
                                                        student.issues.map((issue, idx) => (
                                                            <span key={idx} className="px-2 py-0.5 text-xs rounded bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 border border-red-100 dark:border-red-800">
                                                                {issue}
                                                            </span>
                                                        ))
                                                    ) : (
                                                        <span className="text-xs text-gray-400 italic">No major issues</span>
                                                    )}
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <button className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 hover:underline">
                                                    Intervene
                                                </button>
                                            </td>
                                        </motion.tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
